<?php

namespace Phrame;

defined('CPATH') OR exit('Access Denied!');

/**
 * Database class
 */
class Database
{
	use \Model\Database;

}