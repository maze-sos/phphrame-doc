<?php

require_once 'app'.DS.'core'.DS.'config.php';
require_once 'app'.DS.'core'.DS.'Database.php';
require_once 'Database.php';
require_once 'Migration.php';
require_once 'Phrame.php';
