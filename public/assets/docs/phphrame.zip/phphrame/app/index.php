<?php 

defined('ROOTPATH') OR exit('Access Denied!');