</main>
    <footer>
        <p>&copy; <?= date('Y') ?> PHPhrame. All rights reserved.</p>
    </footer>
</body>
</html>
